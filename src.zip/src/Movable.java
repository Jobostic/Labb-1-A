public interface Movable {
    public void move();

    public void turnLeft();

    public void turnRight();
}
